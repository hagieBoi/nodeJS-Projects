/*Section 5 assignment 3
 * 
 *Express JS assignment
 *Seth Hager
 *April 8th 2020
 * 
 * 
 *Goals:
 * Create a npm project and install Express.js (Optionally Nodemon)
 * 
 * Serve two HTML files for "/" and "/users"
 * 
 * Statically serve a file, such as javascript or CSS
 * 
 */

//NodeJS provided dependencies
const http = require(`http`);
const path = require('path');

//3rd party dependencies
const express = require(`express`);
const bodyParser = require('body-parser');

//declaration of app const to init expressJS
const app = express();

//middleware
app.use(bodyParser.urlencoded({extended:false})); //Parse request data
app.use(express.static(path.join(__dirname, `./views/public`))); //Statically server CSS stylesheet

//user defined middleware
app.use("/users", (req, res, next) =>
    {
    res.sendFile(path.join(__dirname, `views/users.html`));
    }
)

app.use("/", (req,res,next)=> {
    res.sendFile(path.join(__dirname, `views/main.html`));
});

app.listen(3000);